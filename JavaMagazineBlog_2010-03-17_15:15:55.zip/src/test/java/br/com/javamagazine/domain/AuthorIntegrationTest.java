package br.com.javamagazine.domain;


@org.springframework.roo.addon.test.RooIntegrationTest(entity = br.com.javamagazine.domain.Author.class)
public class AuthorIntegrationTest {

    @org.junit.Test
    public void testMarkerMethod() {
    }
}
