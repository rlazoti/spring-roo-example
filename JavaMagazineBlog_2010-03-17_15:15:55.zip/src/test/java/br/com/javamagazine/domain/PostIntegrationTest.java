package br.com.javamagazine.domain;


@org.springframework.roo.addon.test.RooIntegrationTest(entity = br.com.javamagazine.domain.Post.class)
public class PostIntegrationTest {

    @org.junit.Test
    public void testMarkerMethod() {
    }
}
