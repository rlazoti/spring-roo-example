package br.com.javamagazine.domain;


@org.springframework.roo.addon.dod.RooDataOnDemand(entity = br.com.javamagazine.domain.Author.class)
public class AuthorDataOnDemand {
}
