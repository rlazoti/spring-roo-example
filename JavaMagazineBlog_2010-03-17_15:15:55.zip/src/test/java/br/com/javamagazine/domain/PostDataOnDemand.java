package br.com.javamagazine.domain;


@org.springframework.roo.addon.dod.RooDataOnDemand(entity = br.com.javamagazine.domain.Post.class)
public class PostDataOnDemand {
}
